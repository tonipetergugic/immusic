"use client";

import { memo } from "react";
import { useRouter } from "next/navigation";
import type { PlayerTrack } from "@/types/playerTrack";
import PlayOverlayButton from "@/components/PlayOverlayButton";
import TrackOptionsTrigger from "@/components/TrackOptionsTrigger";
import TrackRatingInline from "@/components/TrackRatingInline";
import TrackRowBase from "@/components/TrackRowBase";
import { formatTrackTitle } from "@/lib/formatTrackTitle";
import { GripVertical } from "lucide-react";

function PlaylistRow({
  track,
  onDelete,
  tracks,
  user,
  dragHandleProps,
}: {
  track: PlayerTrack;
  tracks: PlayerTrack[];
  onDelete?: () => void;
  user: any | null;
  dragHandleProps?: {
    listeners?: Record<string, any>;
    setActivatorNodeRef: (node: HTMLButtonElement | null) => void;
  };
}) {
  const router = useRouter();

  const currentIndex = tracks.findIndex((t) => t.id === track.id);

  function goToTrack(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    const releaseId = (track as any)?.release_id ?? null;
    router.push(releaseId ? `/dashboard/release/${releaseId}` : `/dashboard/track/${track.id}`);
  }

  function goToArtist(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();

    router.push(`/dashboard/artist/${track.artist_id}`);
  }

  function goToArtistId(artistId: string, e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    router.push(`/dashboard/artist/${artistId}`);
  }

  return (
    <div className="cursor-default">
      <TrackRowBase
        track={track}
        index={Math.max(currentIndex, 0)}
        tracks={tracks}
        coverSize="md"
        className="border-b-0" // ✅ border comes from wrapper (DnD wrapper), not from TrackRowBase
        leadingSlot={
          <div className="flex items-center gap-1">
            {dragHandleProps ? (
              <button
                ref={dragHandleProps.setActivatorNodeRef}
                type="button"
                aria-label="Reorder track"
                className="
      -ml-1 p-1 rounded
      text-white/40 hover:text-white/70
      cursor-grab active:cursor-grabbing
      touch-none
    "
                {...(dragHandleProps.listeners ?? {})}
              >
                <GripVertical size={16} />
              </button>
            ) : null}

            <div className="text-white/50 text-[11px] tabular-nums px-1 py-1">
              {currentIndex + 1}
            </div>
          </div>
        }
        titleSlot={
          <button
            type="button"
            onPointerDown={(e) => {
              e.preventDefault();
              e.stopPropagation();
            }}
            onClick={goToTrack}
            className="
            text-left text-[13px] font-semibold text-white truncate
            hover:text-[#00FFC6] transition-colors
            focus:outline-none
          "
            title={formatTrackTitle(track.title, (track as any).version)}
          >
            {formatTrackTitle(track.title, (track as any).version)}
          </button>
        }
        subtitleSlot={
          Array.isArray((track as any)?.artists) && (track as any).artists.length > 0 ? (
            <div className="mt-1 text-left text-xs text-white/60 truncate">
              {(track as any).artists.map((a: any, idx: number) => (
                <span key={a.id}>
                  <button
                    type="button"
                    onPointerDown={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                    }}
                    onClick={(e) => goToArtistId(String(a.id), e)}
                    className="
                      hover:text-[#00FFC6] hover:underline underline-offset-2
                      transition-colors
                      focus:outline-none
                    "
                    title={String(a.display_name)}
                  >
                    {String(a.display_name)}
                  </button>
                  {idx < (track as any).artists.length - 1 ? ", " : null}
                </span>
              ))}
            </div>
          ) : track.profiles?.display_name ? (
            <button
              type="button"
              onPointerDown={(e) => {
                e.preventDefault();
                e.stopPropagation();
              }}
              onClick={goToArtist}
              className="
            mt-1 text-left text-xs text-white/60 truncate
            hover:text-[#00FFC6] hover:underline underline-offset-2
            transition-colors
            focus:outline-none
          "
              title={track.profiles.display_name}
            >
              {track.profiles.display_name}
            </button>
          ) : (
            <div className="mt-1 text-xs text-white/40 truncate">Unknown artist</div>
          )
        }
        metaSlot={
          track.release_track_id ? (
            <TrackRatingInline
              releaseTrackId={track.release_track_id}
              initialAvg={(track as any).rating_avg ?? null}
              initialCount={(track as any).rating_count ?? 0}
              initialStreams={(track as any).stream_count ?? 0}
              initialMyStars={(track as any).my_stars ?? null}
              showStreamsOnDesktopOnly={true}
            />
          ) : (
            <span className="text-xs text-white/60">★</span>
          )
        }
        bpmSlot={<span>{track.bpm ?? "—"}</span>}
        keySlot={<span>{track.key ?? "—"}</span>}
        genreSlot={null}
        actionsSlot={<TrackOptionsTrigger track={track} onRemove={onDelete} tracks={tracks} />}
      />
    </div>
  );
}

export default memo(PlaylistRow);
