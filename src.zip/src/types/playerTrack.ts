export type PlayerTrack = {
  id: string;
  title: string;
  version?: string | null;
  artist_id: string;
  artists?: { id: string; display_name: string }[];
  cover_url: string | null;
  audio_url: string;
  bpm?: number | null;
  key?: string | null;
  genre?: string | null;
  profiles?: {
    display_name?: string | null;
  };
  release_id?: string | null;
  release_track_id?: string | null;
  rating_avg?: number | null;
  rating_count?: number | null;
  my_stars?: number | null;
};

